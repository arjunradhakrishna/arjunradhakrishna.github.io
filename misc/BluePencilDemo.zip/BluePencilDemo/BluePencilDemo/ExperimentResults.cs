﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSLA2019
{
    struct Result
    {
        public bool Success;

        public bool Timeout;
    }

    class ExperimentResults {
        public string PrintResults(Result condition1, Result condition2, Result condition3, Result condition4)
        {
            bool condition1Success = condition1.Success;  // Change the line to "string condition1Success = condition1.Timeout ? "Timeout" : condition1.Success.ToString()"
            bool condition2Success = condition2.Success;  // Change the line to "string condition2Success = condition2.Timeout ? "Timeout" : condition2.Success.ToString()"
            bool condition3Success = condition3.Success;  // Should automatically be suggested. Right click or press Ctrl+. to see the suggestion
            bool condition4Success = condition4.Success;  // Should automatically be suggested. Right click or press Ctrl+. to see the suggestion
            return condition1Success + ", " + condition2Success + ", " + condition3Success + ", " + condition4Success + ", ";
        }
    }
}
