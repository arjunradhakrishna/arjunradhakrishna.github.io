﻿using System;
using System.Collections.Generic;
using System.Linq;
using Stubs;

namespace BluePencilDemo
{
    class Temperature
    {
        static void Main(string[] args)
        {
            foreach(string s in args)
            {
                if(s!=null)
                {
                    if(s.Length>0 && s.Substring(s.Length -1).Equals("F"))
                    {
                        string tempFString = s.Substring(0, s.Length - 1);
                        float tempF = System.Convert.ToSingle(tempFString);

                        Console.WriteLine((tempF - 32) * (5 / 9));  // Replace everything inside paranthesis with TemperatureConversions.FtoC(tempF) // (step 1)
                    }
                    if (s.Length > 0 && s.Substring(s.Length - 1).Equals("C"))
                    {
                        string tempCString = s.Substring(0, s.Length - 1);
                        float tempC = System.Convert.ToSingle(tempCString);

                        Console.WriteLine(tempC * (9 / 5) + 32);
                    }
                }
            }
        }

        static float MinTempInC(List<float> fTemps)
        {
            float fMin = fTemps.ElementAt<float>(0);

            foreach(float f in fTemps)
            {
                if(f < fMin)
                {
                    fMin = f; 
                }
            }

            return (fMin - 32) * (5 / 9); // Replace everything after return with TemperatureConversions.FtoC(fMin) // (step 2)
        }

        static float MaxTempInC(List<float> fTemps)
        {
            float fMax = fTemps.ElementAt<float>(0);

            foreach (float f in fTemps)
            {
                if (f < fMax)
                {
                    fMax = f;
                }
            }

            return (fMax - 32) * (5 / 9); // Should automatically be suggested. Right click or use Ctrl+. to see suggestion (step 3)
        }

        static float AveFTempInC(List<float> fTemps)
        {
            float fTot = 0;
            float fAve ;

            foreach (float f in fTemps)
            {
                fTot += f;
            }
            fAve = fTot / fTemps.Count;

            return (fAve - 32) * (5 / 9); // Should automatically be suggested. Right click or use Ctrl+. to see suggestion (step 3)
        }
    }
}
