﻿using System;
using System.Threading;

// Ignore this file. It is mostly for missing class and method implementations.

namespace Stubs
{
    public static class TemperatureConversions
    {
        public static float FtoC(float temperatureInF)
        {
            //T(°C) = (T(°F) - 32) × 5 / 9
            float temperatureInC = (temperatureInF - 32) * (5 / 9);
            return temperatureInC;
        }

        public static float CtoF(float temperatureInC)
        {
            //T(°F) = (T(°C) × 9 / 5) + 32
            float temperatureInF = (temperatureInC * (9 / 5)) + 32;
            return temperatureInF;
        }

    }

    public class SyntaxTree
    {
        internal SyntaxToken FindTokenOnLeftOfPosition(int position, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }

    public class SyntaxToken
    {
        internal SyntaxToken GetPreviousTokenIfTouchingWord(int position)
        {
            throw new NotImplementedException();
        }

        internal SyntaxKind Kind()
        {
            throw new NotImplementedException();
        }

        internal bool IsParentKind(SyntaxKind attributeList)
        {
            throw new NotImplementedException();
        }

        internal bool IsKind(SyntaxKind openBracketToken)
        {
            throw new NotImplementedException();
        }

        internal SyntaxNode Parent { get; }
    }

    internal class SyntaxNode
    {
        public SyntaxNode Parent { get; internal set; }

        internal SyntaxKind Kind()
        {
            throw new NotImplementedException();
        }

        internal bool IsParentKind(SyntaxKind attribute)
        {
            throw new NotImplementedException();
        }

        internal bool IsKind(SyntaxKind aliasQualifiedName)
        {
            throw new NotImplementedException();
        }
    }

    internal class BaseTypeDeclarationSyntax : SyntaxNode
    {
    }

    public enum SyntaxKind
    {
        OpenBraceToken,
        AttributeList,
        CommaToken,
        ColonToken,
        QualifiedName,
        AliasQualifiedName,
        Attribute,
        AttributeTargetSpecifier,
        OpenBracketToken
    }
}
