﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BluePencilDemo
{
    public static class Logger // remove static here (step 1)
    {
        // public static Logger Instance = new Logger(); // Uncomment this (step 2)

        public static void LogInfo(string msg, string sender)  // remove static here and add ="" to the last argument. Should be "public void LogInfo(string msg, string sender="")" (step 3) 
        {
            Console.WriteLine($"{sender}: {msg}");
        }

        public static void Main()
        {
            // Stuff
            Logger.LogInfo("Event", "");   // Make this Logger.Instance and remove last argument (step 4)

            // More stuff
            Logger.LogInfo("Strange event", ""); // Make this Logger.Instace and remove last argument (step 5)

            // Do stuff
            Logger.LogInfo("Another event", ""); // Logger.Instance should automatically be suggested. Right click or press Ctrl+. to see the suggestion (step 6)

            // Finish
            Logger.LogInfo("Expected event", ""); // Logger.Instance should automatically be suggested. Right click or press Ctrl+. to see the suggestion (step 6)
        }
    }
}
