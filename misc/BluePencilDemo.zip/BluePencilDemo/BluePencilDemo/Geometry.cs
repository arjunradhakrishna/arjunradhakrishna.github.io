﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPSLA2019
{
    class Geometry {
        Random random = new Random();

        bool NextBool() => random.NextDouble() < 0.5;

        public bool? HasHeader;
        public int? MinColumnCount;
        public int? MaxColumnCount;
        public int? MinRowCount;
        public int? MaxRowCount;
        public bool? HorizontalOuterBorder;
        public bool? VerticalOuterBorder;
        public bool? HeaderLine;
        public bool? BoldHeader;
        public double? RowBorderRatio;
        public double? ColumnBorderRatio;
        public int? MaxMultiWordsColumn;
        public double? MergeRowsRatio;
        public double? NumberColumnRatio;
        public double? SingleWordColumnRatio;
        public double? MissingValuesRatio;

        public void Materialize(Random random)
        {
            // (step 1) Replace with HasHeader = HasHeader ?? NextBool();
            if (!HasHeader.HasValue)
            {
                HasHeader = NextBool();
            }

            // (step 2) Replace with MinColumnCount = MinColumnCount ?? 2;
            if (!MinColumnCount.HasValue)
            {
                MinColumnCount = 2;
            }

            // Should be automatically suggested. Right click or Ctrl+. to see suggestion.
            if (!MaxColumnCount.HasValue)
            {
                MaxColumnCount = 10;
            }

            // The rest should be automatically suggested. Right click or Ctrl+. to see suggestion.
            if (!MinRowCount.HasValue)
            {
                MinRowCount = 2;
            }

            if (!MaxRowCount.HasValue)
            {
                MaxRowCount = 10;
            }

            if (!HorizontalOuterBorder.HasValue)
            {
                HorizontalOuterBorder = NextBool();
            }

            if (!VerticalOuterBorder.HasValue)
            {
                VerticalOuterBorder = NextBool();
            }

            if (!HeaderLine.HasValue)
            {
                HeaderLine = NextBool();
            }

            if (!BoldHeader.HasValue)
            {
                BoldHeader = NextBool();
            }

            if (!RowBorderRatio.HasValue)
            {
                RowBorderRatio = random.NextDouble();
            }

            if (!ColumnBorderRatio.HasValue)
            {
                ColumnBorderRatio = random.NextDouble();
            }

            if (!MaxMultiWordsColumn.HasValue)
            {
                MaxMultiWordsColumn = 1;
            }

            if (!MergeRowsRatio.HasValue)
            {
                MergeRowsRatio = 0.0;
            }

            if (!NumberColumnRatio.HasValue)
            {
                NumberColumnRatio = random.NextDouble();
            }

            if (!SingleWordColumnRatio.HasValue)
            {
                SingleWordColumnRatio = random.NextDouble();
            }

            if (!MissingValuesRatio.HasValue)
            {
                MissingValuesRatio = random.NextDouble() / 5;
            }
        }
    }
}
