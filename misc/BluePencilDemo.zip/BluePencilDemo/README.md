
Ensure that you have Visual Studio 2019 version 16.7 or later installed.

Open `BluePencilDemo.sln` and follow instructions in each `.cs` file.
